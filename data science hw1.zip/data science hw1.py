#I should use .readiness to read a file and put into the language
#strip spilt to make the data more clear
# int()for count the data
# range for cycle the data
# min max sorted sum for stat
# len()for aount
# index() for find the location
# append  for add a thing to the set
#format to control the format of number

#1:read the file use .readlines
files=open("europe_population.csv", "r")
lines=files.readlines()
print("Q1")
for line in lines:
    print(line, end="")

#2:rank the term in first year survial rate
city=lines[0].strip().split(",")#city
age0=lines[1].strip().split(",")#intial amount
age1=lines[2].strip().split(",")#firstyear
#rate=first year/1000
surviving_rate=[]
for i in range(1,len(city)):
    S=int(age0[i])#starting and ending population
    E=int(age1[i])
    rate=E/S
    surviving_rate.append([city[i],rate])
    surviving_rate.sort(key=lambda x:x[1],reverse=True)#rank
print("Q2") 
for i in range(len(surviving_rate)):
    region=surviving_rate[i][0]
    rates=surviving_rate[i][1] * 100#%100
    print(i+1,region,rates)

#3 medium rate in first year
median_place=surviving_rate[5][0]#already rank use Q2
median_rate=surviving_rate[5][1]
print("Q3")
print("Median place:", median_place)
print(median_rate)

#4 death rate=s-e/s use strip and spliit
#4 death rate=(s-e)/s
death_rates=[]
#11 city use start population -end population / start population 
for i in range(1,len(city)):
    place = city[i]
    place_death_rates=[]
    for age in range(90):
        s=int(lines[age+1].strip().split(",")[i])
        e=int(lines[age+2].strip().split(",")[i])
        death_rate=(s-e)/s
        place_death_rates.append(death_rate)

    death_rates.append([place,place_death_rates])
#open the file
output_file=open("europe_population.csv","w")
output_file.write("Ages")

for item in death_rates:
    output_file.write("," + item[0])

output_file.write("\n")

for age in range(90):
    output_file.write(str(age))

    for item in death_rates:
        rate=item[1][age]
        output_file.write("," + str(rate))

    output_file.write("\n")
output_file.close()

print("Q4")
print("Death rates were written to europe_population_death_rates.csv")
#5 
for item in death_rates:#solve one by one
    place=item[0]#from Q4 place=city
    rates=item[1]
    minimum=min(rates)
    maximum=max(rates)
    average=sum(rates)/len(rates)#len for counting
    sorted_rates=sorted(rates)#rank
    n=len(sorted_rates)#90
    if n%2==1:
    #Determine whether the number is odd or even
    #and based on the result, find the median.
        median=sorted_rates[n//2]
    else:
        middle1=sorted_rates[n//2-1]
        middle2=sorted_rates[n//2]
        median=(middle1 + middle2)/2
    place_index = city.index(place)#find the city's row
    s=int(lines[1].strip().split(",")[place_index])#same as Q4
    #annual death =S(1+r)*n
    annualized_rate = ((e/s)** (1/90)) - 1
    print(place)
    print("Minimum:", "{:.2f}%".format(minimum*100))
    print("Maximum:", "{:.2f}%".format(maximum*100))
    print("Average:", "{:.2f}%".format(average*100))
    print("Median:", "{:.2f}%".format(median*100))
    print("Annualized:", "{:.2f}%".format(annualized_rate * 100))
    print()   

    #6&7
    #Which places had the highest&lowest average, median, and annualized death

results = []
for item in death_rates:#copy Q4
    place=item[0]
    rates=item[1]
    average=sum(rates) / len(rates)
    sorted_rates = sorted(rates)
    n = len(sorted_rates)
    if n % 2==1:#same as previous
        median=sorted_rates[n // 2]
    else:
        middle1=sorted_rates[n // 2 - 1]
        middle2=sorted_rates[n // 2]
        median=(middle1 + middle2) / 2
    place_index = city.index(place)
    s = int(lines[1].strip().split(",")[place_index])
    e = int(lines[91].strip().split(",")[place_index])
    annualized_rate = ((e / s) ** (1 / 90)) - 1
    results.append([place, average, median, annualized_rate])
#use lambda to rank use the second element to rank
highest_average=max(results, key=lambda x: x[1])
highest_median=max(results, key=lambda x: x[2])
highest_annualized=max(results, key=lambda x: x[3])
lowest_average=min(results, key=lambda x: x[1])
lowest_median=min(results, key=lambda x: x[2])
lowest_annualized=min(results, key=lambda x: x[3])
print()
print("Q6&Q7")
print("Highest average death rate:",highest_average[0], "{:.2f}%".format(highest_average[1]*100))
print("Highest median death rate:", highest_median[0],"{:.2f}%".format(highest_median[2]*100))
print("Highest annualized death rate:",highest_annualized[0],"{:.2f}%".format(highest_annualized[3]*100))
print()
print("Lowest average death rate:",lowest_average[0],"{:.2f}%".format(lowest_average[1]*100))
print("Lowest median death rate:", lowest_median[0],"{:.2f}%".format(lowest_median[2]*100))
print("Lowest annualized death rate:",lowest_annualized[0],"{:.2f}%".format(lowest_annualized[3]*100))

# Q8
# for every age (>1) and every place, assign "+" if the death rate for
#that year if greater or equal to the death rate in the previous year.
#Assign "-" if the death rate for that year is less (i.e., decreased) than page 2
#Homework- Medieval Europe Population
#the death rate in the previous year. With these labels, every place
#is assigned a sequence like "+ + − − −+−···−+. For each such
#sequence, compute the following statistics and put the results in the table

print("Q8")

for item in death_rates:
    place = item[0]
    rates = item[1]

    plus_count = 0
    minus_count = 0

    max_plus = 0
    max_minus = 0

    current_plus = 0
    current_minus = 0
    for i in range(1, len(rates)):
        if rates[i] >= rates[i - 1]:
            plus_count = plus_count + 1
            current_plus = current_plus + 1
            current_minus = 0

            if current_plus > max_plus:
                max_plus = current_plus
        else:
            minus_count = minus_count + 1
            current_minus = current_minus + 1
            current_plus = 0

            if current_minus > max_minus:
                max_minus = current_minus

    print(
        place,
        "# -:", minus_count,
        "# +:", plus_count,
        "max consecutive -:", max_minus,
        "max consecutive +:", max_plus
    )
# Q9 find 3 places with sharp increasing death rates
results=[]
for item in death_rates:
    place=item[0]
    rates=item[1]
    max_plus=0#how many it increase countiniously
    plus_now=0#how many times of the longest 1
    for i in range(2, len(rates)):
        if rates[i]>=rates[i-1]:
            plus_now=plus_now+1
            if plus_now>max_plus:
                max_plus=plus_now
        else:
            plus_now=0
    results.append([place,max_plus])
results.sort(key=lambda x: x[1], reverse=True)
print()
print("Question 9")
for i in range(3):
    print(i+1, results[i][0], results[i][1])

#Q10
results = []
for item in death_rates:
    place = item[0]
    rates = item[1]
    max_minus = 0#same as Q9
    minus_now = 0
    for i in range(2, len(rates)):
        if rates[i] < rates[i - 1]:
            minus_now = minus_now + 1
            if minus_now > max_minus:
                max_minus = minus_now
        else:
            minus_now = 0
    results.append([place, max_minus])
results.sort(key=lambda x: x[1], reverse=True)
print()
print("Question 10")
for i in range(3):
    print(i + 1, results[i][0], results[i][1])
results = []

for item in death_rates:
    place = item[0]
    rates = item[1]
    max_minus=0
    minus_now=0
    for i in range(2, len(rates)):
        if rates[i]<rates[i - 1]:
            minus_now=minus_now + 1

            if minus_now>max_minus:
                max_minus=minus_now
        else:
            minus_now=0

    results.append([place, max_minus])

results.sort(key=lambda x: x[1], reverse=True)
print()
print("Question 10")
for i in range(3):
    print(i + 1, results[i][0], results[i][1])

#11
# The consequence illustrates the death rates change over age and every place have different situation. For the most of the place
# s, the death rates increase. For the exetremum, Bleflaw have the increasing sequence, which has 34 continious increases. Holland
#  and Nothampton also have long increase. By contrast, THe Norwich and France have the longest decreasing sequences, with 11 
# consecutive decreases.All in all, the increasing periods of death dates are more common than decreasing one.

#12 I suppose that pinocchio plagiariaed and violated academic code. so it's c!